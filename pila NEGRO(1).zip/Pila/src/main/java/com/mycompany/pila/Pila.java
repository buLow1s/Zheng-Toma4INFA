/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pila;

/**
 *
 * @author yetty
 */
import java.util.ArrayDeque;
import java.util.Deque;

public class Pila {
    public static void main(String[] args) {
        System.out.println("--- ESERCIZIO: STRUTTURA PILA (LIFO) ---");
        
        Deque<Integer> pila = new ArrayDeque<>();

        pila.push(10);
        pila.push(20);
        pila.push(30);
        System.out.println("Pila dopo il popolamento (cima a sinistra): " + pila);

        int rimosso = pila.pop();
        System.out.println("Elemento rimosso (pop): " + rimosso);

        pila.push(100);
        System.out.println("Inserito nuovo elemento: 100");

        System.out.println("Contenuto finale della Pila: " + pila);
    }
}
